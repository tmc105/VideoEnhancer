## Video Enhancer Privacy Policy 

- Video Enhancer does not collect, store, or transmit personal information.
- The extension only saves your enhancer settings (sharpen, contrast, saturation, panel visibility/position) locally via Chrome's storage API so they persist between visits.
- No data leaves your browser and nothing is shared with third parties.

